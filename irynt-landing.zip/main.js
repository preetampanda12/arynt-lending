// IRYNT landing: motion and behaviour. Everything degrades to a readable static page
// without JS. Motion runs for every visitor, including with prefers-reduced-motion (site owner's choice).
(() => {
  const root = document.documentElement;
  root.classList.add('js');
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  // ── Headlines: wrap each word so it can rise out of a mask, keeping <em> and spaces.
  const splitWords = (el) => {
    let i = 0;
    const walk = (node) => {
      [...node.childNodes].forEach((child) => {
        if (child.nodeType === Node.TEXT_NODE) {
          const parts = child.textContent.split(/(\s+)/);
          const frag = document.createDocumentFragment();
          parts.forEach((part) => {
            if (!part) return;
            if (/^\s+$/.test(part)) {
              frag.append(part);
              return;
            }
            const outer = document.createElement('span');
            outer.className = 'w';
            const inner = document.createElement('span');
            inner.textContent = part;
            inner.style.setProperty('--i', String(i++));
            outer.append(inner);
            frag.append(outer);
          });
          child.replaceWith(frag);
        } else if (child.nodeType === Node.ELEMENT_NODE) {
          walk(child);
        }
      });
    };
    walk(el);
  };
  const splits = [...document.querySelectorAll('[data-split]')];
  splits.forEach(splitWords);
  const loadSplits = splits.filter((el) => el.dataset.split === 'load');
  const showLoad = () => loadSplits.forEach((el) => el.classList.add('is-in'));
  (document.fonts?.ready ?? Promise.resolve()).then(() => requestAnimationFrame(showLoad));
  setTimeout(showLoad, 1200); // never leave the hero hidden if fonts are slow

  // ── Reveals: cards, rows and headings fade or wipe in once, staggered within a group.
  const reveals = [...document.querySelectorAll('.reveal'), ...splits.filter((el) => el.dataset.split !== 'load')];
  const groups = new Map();
  document.querySelectorAll('.reveal').forEach((el) => {
    const n = groups.get(el.parentElement) ?? 0;
    groups.set(el.parentElement, n + 1);
    el.style.setProperty('--d', `${Math.min(n, 7) * 80}ms`);
  });
  const countUp = (el) => {
    const target = Number(el.dataset.count);
    if (!target) return;
    const start = performance.now();
    const dur = 1400;
    const tick = (now) => {
      const t = clamp((now - start) / dur, 0, 1);
      el.textContent = String(Math.round(target * (1 - Math.pow(1 - t, 3))));
      if (t < 1) requestAnimationFrame(tick);
    };
    el.textContent = '0';
    requestAnimationFrame(tick);
  };
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add('is-in');
          entry.target.querySelectorAll('[data-count]').forEach(countUp);
          // Photo tiles wipe open only once their image has arrived (they lazy-load).
          if (entry.target.classList.contains('tile')) {
            const img = entry.target.querySelector('img');
            const ready = () => entry.target.classList.add('img-ready');
            if (img?.complete && img.naturalWidth) ready();
            else img?.addEventListener('load', ready, { once: true });
          }
          io.unobserve(entry.target);
        });
      },
      { rootMargin: '0px 0px -10% 0px', threshold: 0.15 },
    );
    reveals.forEach((el) => io.observe(el));
  } else {
    reveals.forEach((el) => el.classList.add('is-in'));
  }

  // ── Header: background once scrolled, hides on the way down, returns on the way up.
  const header = document.querySelector('[data-header]');
  const progress = document.querySelector('.scroll-progress');
  let lastY = window.scrollY;

  // ── Parallax photos and the pinned journey are driven from one rAF scroll loop.
  const parallax = [...document.querySelectorAll('[data-parallax] img')];
  const sealsBox = document.querySelector('.seals');
  const sealSpins = [...document.querySelectorAll('.seal-spin')];
  const journey = document.querySelector('[data-journey]');
  const track = journey?.querySelector('.journey-track');
  const stops = journey ? [...journey.querySelectorAll('.stop')] : [];
  // Pinned sideways journey on every screen tall enough to show a whole card. It moves only
  // as the visitor scrolls.
  const setPinned = () => {
    const pinned = window.innerHeight >= 520;
    journey?.classList.toggle('is-pinned', pinned);
    // The swipe row needs a tab stop so keyboards can scroll it; the pinned row scrolls with the page.
    if (pinned) track?.removeAttribute('tabindex');
    else track?.setAttribute('tabindex', '0');
  };
  setPinned();
  window.addEventListener('resize', () => {
    setPinned();
    requestAnimationFrame(onScroll);
  });

  let ticking = false;
  function onScroll() {
    ticking = false;
    const y = window.scrollY;
    const vh = window.innerHeight;
    header?.toggleAttribute('data-scrolled', y > 12);
    const menuOpen = document.getElementById('site-nav')?.hasAttribute('data-open');
    header?.toggleAttribute('data-hidden', !menuOpen && y > 400 && y > lastY + 4);
    if (y < lastY - 4 || y < 400) header?.removeAttribute('data-hidden');
    lastY = y;

    const max = document.documentElement.scrollHeight - vh;
    progress?.style.setProperty('--progress', String(max > 0 ? y / max : 0));

    {
      parallax.forEach((img) => {
        const box = img.parentElement.getBoundingClientRect();
        if (box.bottom < 0 || box.top > vh) return;
        const center = box.top + box.height / 2 - vh / 2;
        img.style.setProperty('--shift', `${(-center * 0.12).toFixed(1)}px`);
      });
    }

    // Seals: scrolling past turns the text rings, alternating direction.
    if (sealsBox) {
      const b = sealsBox.getBoundingClientRect();
      if (b.bottom > 0 && b.top < vh) {
        const p = clamp((vh - b.top) / (vh + b.height), 0, 1);
        sealSpins.forEach((el, i) => el.style.setProperty('--scroll-rot', ((p * 260 - 130) * (i % 2 ? -1 : 1)).toFixed(1) + 'deg'));
      }
    }

    if (journey && track) {
      const box = journey.getBoundingClientRect();
      if (journey.classList.contains('is-pinned')) {
        const span = journey.offsetHeight - vh;
        const p = clamp(-box.top / span, 0, 1);
        // Travel until the last card is centred (phones, tablets) or sits a gutter from the edge (desktop).
        const last = stops[stops.length - 1];
        const vwNow = window.innerWidth;
        const gutter = parseFloat(getComputedStyle(track).paddingLeft) || 0;
        const end = vwNow < 900 ? last.offsetLeft + last.offsetWidth / 2 - vwNow / 2 : last.offsetLeft + last.offsetWidth + Math.min(gutter, 80) - vwNow;
        const distance = Math.max(0, end);
        track.style.setProperty('--track-x', `${(-p * distance).toFixed(1)}px`);
        journey.style.setProperty('--journey', p.toFixed(4));
        // The card nearest the centre comes forward; the others recede.
        const vw = window.innerWidth;
        stops.forEach((s) => {
          const r = s.getBoundingClientRect();
          const d = Math.abs(r.left + r.width / 2 - vw / 2);
          s.style.setProperty('--focus', clamp(1 - d / (vw * 0.85), 0, 1).toFixed(3));
        });
      } else {
        const p = track.scrollWidth > track.clientWidth ? track.scrollLeft / (track.scrollWidth - track.clientWidth) : 0;
        journey.style.setProperty('--journey', p.toFixed(4));
      }
    }
  }
  const requestTick = () => {
    if (!ticking) {
      ticking = true;
      requestAnimationFrame(onScroll);
    }
  };
  window.addEventListener('scroll', requestTick, { passive: true });
  window.addEventListener('resize', requestTick);
  track?.addEventListener('scroll', requestTick, { passive: true });
  onScroll();

  // ── Hero: the route panel tilts toward the pointer, the pass drifts the other way.
  const tilt = document.querySelector('[data-tilt]');
  const panel = tilt?.querySelector('.routes-panel');
  const pass = tilt?.querySelector('.pass');
  if (tilt && panel && pass) {
    tilt.addEventListener('pointermove', (e) => {
      if (!finePointer.matches) return;
      const r = tilt.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const yy = (e.clientY - r.top) / r.height - 0.5;
      panel.style.setProperty('--rx', `${(-yy * 6).toFixed(2)}deg`);
      panel.style.setProperty('--ry', `${(x * 8).toFixed(2)}deg`);
      pass.style.setProperty('--px', `${(-x * 14).toFixed(1)}px`);
      pass.style.setProperty('--py', `${(-yy * 10).toFixed(1)}px`);
    });
    tilt.addEventListener('pointerleave', () => {
      ['--rx', '--ry'].forEach((v) => panel.style.removeProperty(v));
      ['--px', '--py'].forEach((v) => pass.style.removeProperty(v));
    });
  }

  // ── Mobile menu: full-screen sheet, closes on link tap and Escape, locks page scroll.
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.getElementById('site-nav');
  const setMenu = (open) => {
    toggle?.setAttribute('aria-expanded', String(open));
    nav?.toggleAttribute('data-open', open);
    document.body.style.overflow = open ? 'hidden' : '';
    const label = toggle?.querySelector('.menu-toggle-label');
    if (label) label.textContent = open ? 'Close' : 'Menu';
  };
  toggle?.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
  nav?.addEventListener('click', (e) => {
    if (e.target instanceof Element && e.target.closest('a')) setMenu(false);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && toggle?.getAttribute('aria-expanded') === 'true') {
      setMenu(false);
      toggle.focus();
    }
  });
  window.matchMedia('(min-width: 960px)').addEventListener('change', (m) => m.matches && setMenu(false));

  // ── Phone action bar: after the hero, hidden while the form or the footer is on screen.
  const bar = document.querySelector('[data-mobile-cta]');
  const hero = document.querySelector('.hero');
  const plan = document.getElementById('plan');
  const footer = document.querySelector('.site-footer');
  if (bar && hero && plan && footer && 'IntersectionObserver' in window) {
    const seen = new Map([[hero, true]]);
    const update = () => bar.toggleAttribute('data-visible', !seen.get(hero) && !seen.get(plan) && !seen.get(footer));
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => seen.set(e.target, e.isIntersecting));
        update();
      },
      { threshold: 0.02 },
    );
    [hero, plan, footer].forEach((el) => io.observe(el));
  }

  // The swipe hint fades once the visitor has swiped the journey row.
  track?.addEventListener('scroll', () => journey?.classList.add('was-swiped'), { once: true, passive: true });

  document.querySelectorAll('[data-year]').forEach((el) => (el.textContent = String(new Date().getFullYear())));

  // ── Plan form: messages next to each field, then POST to data-endpoint.
  const form = document.getElementById('plan-form');
  if (!form) return;
  const status = form.querySelector('.form-status');
  const submit = form.querySelector('button[type="submit"]');
  const rules = {
    name: (v) => v.trim().length >= 2,
    country: (v) => v.trim().length >= 2,
    phone: (v) => v.replace(/[^\d]/g, '').length >= 8,
  };
  const check = (input) => {
    const rule = rules[input.name];
    const ok = input.type === 'checkbox' ? input.checked : rule ? rule(input.value) : true;
    const err = document.getElementById(`${input.id}-err`);
    input.setAttribute('aria-invalid', String(!ok));
    if (err) {
      err.hidden = ok;
      if (!ok) input.setAttribute('aria-describedby', err.id);
      else input.removeAttribute('aria-describedby');
    }
    return ok;
  };
  const fields = [...form.querySelectorAll('#f-name, #f-country, #f-phone, #f-consent')];
  fields.forEach((input) => {
    input.addEventListener('blur', () => input.value !== '' && input.type !== 'checkbox' && check(input));
    input.addEventListener('input', () => input.getAttribute('aria-invalid') === 'true' && check(input));
    input.addEventListener('change', () => input.type === 'checkbox' && check(input));
  });
  const show = (html, isError = false) => {
    status.innerHTML = html;
    status.classList.toggle('is-error', isError);
    status.hidden = false;
  };
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const results = fields.map(check);
    const firstBad = fields[results.indexOf(false)];
    if (firstBad) {
      firstBad.focus();
      return;
    }
    submit.setAttribute('aria-busy', 'true');
    submit.disabled = true;
    const endpoint = form.dataset.endpoint;
    try {
      if (endpoint) {
        const res = await fetch(endpoint, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
      } else {
        // No endpoint configured yet: log the request for testing.
        console.info('IRYNT plan request (set data-endpoint on #plan-form to send it):', Object.fromEntries(new FormData(form)));
        await new Promise((r) => setTimeout(r, 600));
      }
      const name = form.elements.name.value.trim().split(/\s+/)[0].replace(/[<>&"]/g, '');
      form.reset();
      fields.forEach((f) => f.removeAttribute('aria-invalid'));
      show(`<strong>Thank you, ${name}.</strong>We will write to you within 48 hours.`);
      status.focus();
    } catch {
      show('<strong>That did not go through.</strong>Please try again, or message us on WhatsApp.', true);
    } finally {
      submit.removeAttribute('aria-busy');
      submit.disabled = false;
    }
  });
})();
